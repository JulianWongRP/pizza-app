import React from 'react';
import ReactDOM from 'react-dom/client';
import SpinaciImg from './assets/spinaci.jpg';
import MargheritaImg from './assets/margherita.jpg';

function App() {
  return (
    <div>
      <Header />
      <PizzaSpinaci />
      <PizzaMargherita />
      <PizzaSpinaci/>
    </div>
  );
}

function Header() {
  return <h1>Julian's Pizza Co.</h1>;
}

function PizzaSpinaci() {
  return (
    <div>
      <img src={SpinaciImg} alt="spinaci" />
      <h2>Pizza Spinaci</h2>
      <p>Tomato, mozzarella, spinach, and ricotta cheese</p>
      <p>10</p>
    </div>
  );
}

function PizzaMargherita() {
  return (
    <div>
      <img src={MargheritaImg} alt="margherita" />
      <h2>Pizza Margherita</h2>
      <p>Tomato, mozzarella, and basil</p>
      <p>5</p>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
